# docstring gen ollama

[![PyPI - Version](https://img.shields.io/pypi/v/docstring-gen-ollama.svg)](https://pypi.org/project/docstring-gen-ollama)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/docstring-gen-ollama.svg)](https://pypi.org/project/docstring-gen-ollama)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install docstring-gen-ollama
```

## License

`docstring-gen-ollama` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
